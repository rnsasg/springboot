package com.narayan.elasticsearchkafkaproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticsearchkafkaproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
