package com.narayan.elasticsearchkafkaconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticsearchkafkaconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
